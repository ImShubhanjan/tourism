# Pledge India Tourism — Travel & Tour Booking Website (Frontend Demo)

An Angular 17 (standalone components) frontend for a travel agency / tour booking
site, built with **static demo data only** — ready for you to review the look,
feel, and flows before any backend work begins.

## What's included

- **Static data as a single source of truth** — `src/assets/data/site-data.json`
  holds all destinations, tour packages, testimonials, and site info. Every
  page reads from this file through `DataService`, so editing the JSON (or
  swapping it for a real API later) updates the whole site.
- **Transparent shared-vs-private vehicle pricing** — every package shows a
  pricing table with "with meals" and "without meals" columns for both a
  shared vehicle and a private vehicle option (`transportOptions` on each
  package in the JSON). Admin can edit these from the Add/Edit package form.
- **Restricted Area Permit callouts** — packages that need a permit (Tsomgo
  Lake, Zuluk, etc.) show a permit note on the detail page (`permitRequired`
  / `permitNote` fields), editable from the admin form.
- **No login for visitors** — everyone can browse the whole site (destinations,
  packages, package detail, about, contact) with no account. Only the admin
  team needs to log in.
- **Admin login with two methods** — username/password (`admin` / `pledge123`),
  or a Mobile OTP flow where the OTP is shown on screen instead of texted,
  since no SMS gateway is connected yet (see `AuthService.requestOtp()` /
  `verifyOtp()` for exactly where to plug in a real provider like MSG91 or
  Twilio). Admin-only routes are protected by route guards, so a visitor never
  even sees the "Add package" screen, not just a disabled button.
- **Contact page → real, fully automatic email + detailed admin notifications**
  — submitting the Contact form:
  1. Saves the enquiry (visible under Admin → Contact queries)
  2. Sends a real email straight to `riyadatascientist@gmail.com` **automatically
     — no click required from the visitor** — via [EmailJS](https://www.emailjs.com),
     a service built exactly for triggering real emails from a page with no
     backend. See "Turning on automatic email sending" below — it takes about
     5 minutes and is the only setup step needed for delivery, since a browser
     genuinely cannot speak SMTP on its own and this site has no server.
  3. Pushes a bell-icon notification for the admin showing the full name,
     email, phone, package, and message — not just a one-line summary.
- **Transparent shared-vs-private vehicle pricing** — every package shows a
  pricing table with "with meals" and "without meals" columns for both a
  shared vehicle and a private vehicle option (`transportOptions` on each
  package in the JSON). Admin can edit these from the Add/Edit package form.
- **Restricted Area Permit callouts** — packages that need a permit (Tsomgo
  Lake, Zuluk, etc.) show a permit note on the detail page (`permitRequired`
  / `permitNote` fields), editable from the admin form.
- **Fully responsive** — tested breakpoints for phone (≤560px), tablet
  (≤900px), and desktop.
- **A distinct 70/20/10 color system**: 70% warm sand, 20% deep teal, 10% coral
  — see `src/styles.scss` for the full token list.
- **"Updates" feed** — a Facebook-style scrollable feed at `/updates` (also
  linked from the navbar and footer). Admin can post text + optional image
  updates from a composer at the top; everyone can scroll through them and
  tap Like. Backed by `FeedService`, persisted to localStorage for the demo.

## Admin login

| Method            | Credentials                                             |
|--------------------|----------------------------------------------------------|
| Username/password | Username: `admin` &nbsp;·&nbsp; Password: `pledge123`   |
| Mobile OTP         | Enter any phone number, then read the OTP shown on screen (demo only — no SMS is actually sent) |

Both are pre-filled/shown on the `/login` page for convenience during the demo.
There is no viewer login — anyone can browse the site without an account. The
"Login / Sign Up" button in the navbar is where an admin gets to either of
the two methods above.

## Turning on automatic email sending

The Contact form is wired to send through [EmailJS](https://www.emailjs.com)
already — it just needs three free credentials pasted in one place before
it will actually deliver mail. Until then, submissions are still saved and
shown to the admin inside the app (bell icon + Admin → Contact queries), so
nothing is lost — email just won't leave the site yet.

1. Create a free account at https://www.emailjs.com (free tier: 200 emails/month)
2. **Email Services** → Add a service (e.g. connect your Gmail account) → copy the **Service ID**
3. **Email Templates** → create a template using these variable names so they match what the code sends:
   `{{from_name}}` `{{from_email}}` `{{phone}}` `{{package}}` `{{message}}`
   — and set the template's "To email" field to `riyadatascientist@gmail.com` → copy the **Template ID**
4. **Account** → **API Keys** → copy the **Public Key**
5. Open `src/app/core/services/notification.service.ts` and paste the three
   values into `EMAILJS_SERVICE_ID`, `EMAILJS_TEMPLATE_ID`, and `EMAILJS_PUBLIC_KEY`
   near the top of the class.

That's it — no other code changes needed. Submissions will then land in the
inbox automatically, the same second the visitor clicks Send.

## Running it locally

You'll need [Node.js](https://nodejs.org) (18+) and the Angular CLI.

```bash
npm install -g @angular/cli   # if you don't already have it
cd pledge-india-tourism
npm install
ng serve -o
```

The site opens at `http://localhost:4200`.

## Project structure

```
src/
  assets/data/site-data.json     ← all static content lives here
  app/
    core/
      models/models.ts           ← TypeScript interfaces for every data shape
      services/
        data.service.ts          ← loads JSON, admin CRUD (persisted to localStorage)
        auth.service.ts          ← mock login / role check
        notification.service.ts ← contact form → admin bell + simulated email
      guards/
        auth.guard.ts             ← must be logged in
        admin.guard.ts            ← must be an admin
    shared/
      navbar/                    ← responsive, role-aware nav + bell icon
      footer/
      notification-bell/
      ticket-card/                ← boarding-pass styled package card
    pages/
      home/ packages/ package-detail/ about/ contact/ login/
      admin/
        admin-dashboard/
        manage-packages/          ← table + add/edit/delete
        manage-packages/package-form/
        manage-queries/           ← view + resolve contact enquiries
```

## Connecting the real backend later

Everything is written so the swap is mechanical, not a rewrite:

1. **Data**: replace the `http.get('assets/data/site-data.json')` call inside
   `DataService.load()` with your real API endpoint(s). Keep returning the
   same `SiteData` shape (or split it into separate endpoints and combine)
   and every component keeps working unchanged.
2. **Auth**: replace the body of `AuthService.login()` (and `requestOtp()` /
   `verifyOtp()` for the OTP tab) with real HTTP calls to your auth and SMS
   endpoints, and store a real token instead of the mock `User` object.
   `isAdmin()` / `isLoggedIn()` / `adminGuard` don't need to change at all if
   your backend returns a `role` field.
3. **Email + notifications**: EmailJS is already wired into
   `NotificationService.sendEmailAutomatically()` — see "Turning on automatic
   email sending" above to activate it. If you'd rather route through your
   own backend later, replace that method's body with a POST to your API
   (which then calls Nodemailer / SendGrid / AWS SES / etc.). If you want
   real-time bell updates across sessions, swap the `BehaviorSubject` for a
   WebSocket or polling subscription — the rest of the bell component
   doesn't need to change.
4. **Image uploads**: the Admin "Add/Edit package" form currently takes image
   URLs directly (so you can preview instantly with any hosted image). Once
   you add file upload, point the same `model.image` / `model.galleryText`
   fields at the URLs your upload endpoint returns.

## Notes on the demo data

- All images are pulled from Unsplash / pravatar URLs so the site looks
  populated immediately — swap these for your own photography whenever ready.
- Admin edits (add/update/delete package) are saved to the browser's
  `localStorage` so the demo persists across refreshes without a database.
  Use the "Reset demo data" call in `DataService.resetDemoData()` (wire it to
  a button anywhere) if you want to clear those changes during a client demo.
