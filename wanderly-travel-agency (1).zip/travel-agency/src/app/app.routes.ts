import { Routes } from '@angular/router';
import { adminGuard } from './core/guards/admin.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home/home.component').then((m) => m.HomeComponent),
  },
  {
    path: 'packages',
    loadComponent: () => import('./pages/packages/packages.component').then((m) => m.PackagesComponent),
  },
  {
    path: 'packages/:id',
    loadComponent: () =>
      import('./pages/package-detail/package-detail.component').then((m) => m.PackageDetailComponent),
  },
  {
    path: 'about',
    loadComponent: () => import('./pages/about/about.component').then((m) => m.AboutComponent),
  },
  {
    path: 'updates',
    loadComponent: () => import('./pages/feed/feed.component').then((m) => m.FeedComponent),
  },
  {
    path: 'contact',
    loadComponent: () => import('./pages/contact/contact.component').then((m) => m.ContactComponent),
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'admin',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./pages/admin/admin-dashboard/admin-dashboard.component').then((m) => m.AdminDashboardComponent),
  },
  {
    path: 'admin/packages',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./pages/admin/manage-packages/manage-packages.component').then((m) => m.ManagePackagesComponent),
  },
  {
    path: 'admin/packages/new',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./pages/admin/manage-packages/package-form/package-form.component').then(
        (m) => m.PackageFormComponent
      ),
  },
  {
    path: 'admin/packages/:id/edit',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./pages/admin/manage-packages/package-form/package-form.component').then(
        (m) => m.PackageFormComponent
      ),
  },
  {
    path: 'admin/queries',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./pages/admin/manage-queries/manage-queries.component').then((m) => m.ManageQueriesComponent),
  },
  { path: '**', redirectTo: '' },
];
