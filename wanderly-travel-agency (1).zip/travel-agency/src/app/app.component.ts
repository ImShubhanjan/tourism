import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { FooterComponent } from './shared/footer/footer.component';
import { DataService } from './core/services/data.service';
import { NotificationService } from './core/services/notification.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, FooterComponent, CommonModule],
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  visibleToast: { id: number; message: string } | null = null;

  constructor(private dataService: DataService, private notificationService: NotificationService) {}

  ngOnInit(): void {
    this.dataService.load().subscribe();
    this.notificationService.toast$.subscribe((toast) => {
      if (!toast) return;
      this.visibleToast = toast;
      setTimeout(() => {
        if (this.visibleToast?.id === toast.id) this.visibleToast = null;
      }, 4000);
    });
  }
}
