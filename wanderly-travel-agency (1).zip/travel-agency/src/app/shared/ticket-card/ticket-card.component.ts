import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TourPackage } from '../../core/models/models';

@Component({
  selector: 'app-ticket-card',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './ticket-card.component.html',
  styleUrl: './ticket-card.component.scss',
})
export class TicketCardComponent {
  @Input({ required: true }) pkg!: TourPackage;
}
