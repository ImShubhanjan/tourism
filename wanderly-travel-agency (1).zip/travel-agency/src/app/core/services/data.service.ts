import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap, shareReplay } from 'rxjs';
import { Destination, SiteData, TourPackage } from '../models/models';

/**
 * DataService is the single place the whole app reads content from.
 *
 * Today: content comes from assets/data/site-data.json (static demo data).
 * Tomorrow: swap the `http.get(...)` call for real API endpoints and every
 * component that consumes packages$ / destinations$ keeps working unchanged.
 *
 * Admin edits (add/update/delete package) are layered on top of the JSON
 * and persisted to localStorage under STORAGE_KEY, so the demo "sticks"
 * between page refreshes without needing a backend yet.
 */
@Injectable({ providedIn: 'root' })
export class DataService {
  private readonly STORAGE_KEY = 'pledge_packages_override';
  private readonly DEST_KEY = 'pledge_destinations_override';

  private siteDataSubject = new BehaviorSubject<SiteData | null>(null);
  private packagesSubject = new BehaviorSubject<TourPackage[]>([]);
  private destinationsSubject = new BehaviorSubject<Destination[]>([]);

  siteData$ = this.siteDataSubject.asObservable();
  packages$ = this.packagesSubject.asObservable();
  destinations$ = this.destinationsSubject.asObservable();

  private loaded$?: Observable<SiteData>;

  constructor(private http: HttpClient) {}

  /** Loads the JSON once per app session and applies any saved admin edits. */
  load(): Observable<SiteData> {
    if (!this.loaded$) {
      this.loaded$ = this.http.get<SiteData>('assets/data/site-data.json').pipe(
        tap((data) => {
          this.siteDataSubject.next(data);
          this.packagesSubject.next(this.applyOverride(this.STORAGE_KEY, data.packages));
          this.destinationsSubject.next(this.applyOverride(this.DEST_KEY, data.destinations));
        }),
        shareReplay(1)
      );
    }
    return this.loaded$;
  }

  get snapshotSiteData(): SiteData | null {
    return this.siteDataSubject.value;
  }

  getPackageById(id: string): TourPackage | undefined {
    return this.packagesSubject.value.find((p) => p.id === id);
  }

  getPackagesByDestination(destinationId: string): TourPackage[] {
    return this.packagesSubject.value.filter((p) => p.destinationId === destinationId);
  }

  // ---------- Admin write operations (persisted to localStorage) ----------

  addPackage(pkg: TourPackage): void {
    const updated = [...this.packagesSubject.value, pkg];
    this.commitPackages(updated);
  }

  updatePackage(pkg: TourPackage): void {
    const updated = this.packagesSubject.value.map((p) => (p.id === pkg.id ? pkg : p));
    this.commitPackages(updated);
  }

  deletePackage(id: string): void {
    const updated = this.packagesSubject.value.filter((p) => p.id !== id);
    this.commitPackages(updated);
  }

  addDestination(dest: Destination): void {
    const updated = [...this.destinationsSubject.value, dest];
    this.commitDestinations(updated);
  }

  generateId(prefix: string): string {
    return `${prefix}_${Date.now().toString(36)}`;
  }

  resetDemoData(): void {
    localStorage.removeItem(this.STORAGE_KEY);
    localStorage.removeItem(this.DEST_KEY);
    const data = this.siteDataSubject.value;
    if (data) {
      this.packagesSubject.next(data.packages);
      this.destinationsSubject.next(data.destinations);
    }
  }

  // ---------- internal helpers ----------

  private commitPackages(list: TourPackage[]): void {
    this.packagesSubject.next(list);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(list));
  }

  private commitDestinations(list: Destination[]): void {
    this.destinationsSubject.next(list);
    localStorage.setItem(this.DEST_KEY, JSON.stringify(list));
  }

  private applyOverride<T>(key: string, fallback: T[]): T[] {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    try {
      return JSON.parse(raw) as T[];
    } catch {
      return fallback;
    }
  }
}
