import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from '../models/models';

/**
 * Frontend-only auth for the demo.
 *
 * Only admins log in — viewers browse the whole site with no account needed,
 * which is why there is no "viewer" credential here at all. There are two
 * demo ways to log in as admin:
 *   1. Username/password: admin / pledge123
 *   2. Mobile OTP: enter any phone number, the OTP is shown on screen
 *      (since no SMS gateway is connected yet) instead of being texted.
 *
 * When the backend is ready:
 *   - Replace `login()`'s body with a real HTTP call to your auth endpoint.
 *   - Replace `requestOtp()` / `verifyOtp()` with calls to your SMS gateway
 *     (e.g. MSG91, Twilio) and a real OTP-verification endpoint.
 * Everyone else in the app keeps talking to `currentUser$` / `isAdmin()`
 * exactly as they do today.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly SESSION_KEY = 'pledge_session';
  private readonly ADMIN_USERNAME = 'admin';
  private readonly ADMIN_PASSWORD = 'pledge123';

  private pendingOtp: string | null = null;
  private pendingOtpPhone = '';

  private currentUserSubject = new BehaviorSubject<User | null>(this.restoreSession());
  currentUser$ = this.currentUserSubject.asObservable();

  login(username: string, password: string): { ok: boolean; error?: string } {
    if (username.trim().toLowerCase() !== this.ADMIN_USERNAME || password !== this.ADMIN_PASSWORD) {
      return { ok: false, error: 'Incorrect username or password. Try the demo credentials shown below.' };
    }
    this.setAdminSession();
    return { ok: true };
  }

  /** Simulates sending an SMS OTP. Returns the code so the UI can display it (demo only). */
  requestOtp(phone: string): string {
    this.pendingOtp = String(Math.floor(1000 + Math.random() * 9000));
    this.pendingOtpPhone = phone;
    return this.pendingOtp;
  }

  verifyOtp(code: string): { ok: boolean; error?: string } {
    if (!this.pendingOtp || code.trim() !== this.pendingOtp) {
      return { ok: false, error: 'Incorrect OTP. Check the code shown above and try again.' };
    }
    this.setAdminSession();
    this.pendingOtp = null;
    return { ok: true };
  }

  logout(): void {
    localStorage.removeItem(this.SESSION_KEY);
    this.currentUserSubject.next(null);
  }

  get currentUser(): User | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!this.currentUserSubject.value;
  }

  isAdmin(): boolean {
    return this.currentUserSubject.value?.role === 'admin';
  }

  private setAdminSession(): void {
    const user: User = { name: 'Riya Sarkar', email: 'admin@pledgeindiatourism.com', role: 'admin' };
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  private restoreSession(): User | null {
    const raw = localStorage.getItem(this.SESSION_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }
}
