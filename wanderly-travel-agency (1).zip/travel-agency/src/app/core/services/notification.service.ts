import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AppNotification, ContactQuery } from '../models/models';

declare const emailjs: any;

export type EmailSendStatus = 'not-configured' | 'sending' | 'sent' | 'failed';

/**
 * Handles everything that happens after a visitor submits the Contact page:
 *  1. Saves the query so the admin can see it under Admin > Queries.
 *  2. Pushes a bell-icon notification for the admin (badge count + dropdown)
 *     with the full name/email/phone/message, not just a one-line summary.
 *  3. Sends a real, fully automatic email to the admin inbox — no click
 *     required from the visitor — via EmailJS. A browser cannot speak SMTP
 *     directly and this site has no backend server, so *some* external
 *     service (or your own backend later) is unavoidable for automatic
 *     sending; EmailJS is the smallest possible version of that (three
 *     pasted strings, free tier, ~5 minutes to set up).
 *
 * ------------------------------------------------------------------
 * TO TURN ON REAL AUTOMATIC EMAIL SENDING:
 *   1. Create a free account at https://www.emailjs.com
 *   2. Email Services -> Add a service (e.g. connect Gmail) -> copy the Service ID
 *   3. Email Templates -> create a template with variables:
 *      {{from_name}} {{from_email}} {{phone}} {{package}} {{message}}
 *      and set "To email" to riyadatascientist@gmail.com -> copy the Template ID
 *   4. Account -> API Keys -> copy the Public Key
 *   5. Paste all three into the constants below.
 * Until those are filled in, sending is skipped (no error thrown) and the
 * enquiry is still saved + shown to the admin in-app.
 * ------------------------------------------------------------------
 */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly QUERIES_KEY = 'pledge_contact_queries';
  private readonly NOTIFS_KEY = 'pledge_admin_notifications';

  private readonly EMAILJS_SERVICE_ID = 'YOUR_SERVICE_ID';
  private readonly EMAILJS_TEMPLATE_ID = 'YOUR_TEMPLATE_ID';
  private readonly EMAILJS_PUBLIC_KEY = 'YOUR_PUBLIC_KEY';

  private queriesSubject = new BehaviorSubject<ContactQuery[]>(this.readList(this.QUERIES_KEY));
  private notificationsSubject = new BehaviorSubject<AppNotification[]>(this.readList(this.NOTIFS_KEY));
  private toastSubject = new BehaviorSubject<{ id: number; message: string } | null>(null);
  private emailStatusSubject = new BehaviorSubject<EmailSendStatus>('not-configured');

  queries$ = this.queriesSubject.asObservable();
  notifications$ = this.notificationsSubject.asObservable();
  toast$ = this.toastSubject.asObservable();
  /** Reflects the live state of the automatic email attempt for the Contact page to display. */
  emailStatus$ = this.emailStatusSubject.asObservable();

  private get emailjsReady(): boolean {
    return (
      this.EMAILJS_SERVICE_ID !== 'YOUR_SERVICE_ID' &&
      this.EMAILJS_TEMPLATE_ID !== 'YOUR_TEMPLATE_ID' &&
      this.EMAILJS_PUBLIC_KEY !== 'YOUR_PUBLIC_KEY' &&
      typeof emailjs !== 'undefined'
    );
  }

  get unreadCount(): number {
    return this.notificationsSubject.value.filter((n) => !n.read).length;
  }

  submitQuery(payload: Omit<ContactQuery, 'id' | 'createdAt' | 'status'>): ContactQuery {
    const query: ContactQuery = {
      ...payload,
      id: `q_${Date.now().toString(36)}`,
      createdAt: new Date().toISOString(),
      status: 'new',
    };
    const queries = [query, ...this.queriesSubject.value];
    this.queriesSubject.next(queries);
    this.persist(this.QUERIES_KEY, queries);

    this.pushAdminNotification({
      title: 'New contact query received',
      body: `${query.name} asked about "${query.relatedPackage || 'General enquiry'}"`,
      link: '/admin/queries',
      meta: {
        name: query.name,
        email: query.email,
        phone: query.phone || 'Not provided',
        relatedPackage: query.relatedPackage || 'General enquiry',
        message: query.message,
      },
    });

    this.sendEmailAutomatically(query);
    this.showToast('Your message has been sent. Our team will reach out shortly.');

    return query;
  }

  markAsRead(queryId: string): void {
    const queries = this.queriesSubject.value.map((q) => (q.id === queryId ? { ...q, status: 'read' as const } : q));
    this.queriesSubject.next(queries);
    this.persist(this.QUERIES_KEY, queries);
  }

  markAsResolved(queryId: string): void {
    const queries = this.queriesSubject.value.map((q) =>
      q.id === queryId ? { ...q, status: 'resolved' as const } : q
    );
    this.queriesSubject.next(queries);
    this.persist(this.QUERIES_KEY, queries);
  }

  markAllNotificationsRead(): void {
    const notifs = this.notificationsSubject.value.map((n) => ({ ...n, read: true }));
    this.notificationsSubject.next(notifs);
    this.persist(this.NOTIFS_KEY, notifs);
  }

  showToast(message: string): void {
    this.toastSubject.next({ id: Date.now(), message });
  }

  // ---------- internal ----------

  private pushAdminNotification(payload: Omit<AppNotification, 'id' | 'createdAt' | 'read'>): void {
    const notif: AppNotification = {
      ...payload,
      id: `n_${Date.now().toString(36)}`,
      createdAt: new Date().toISOString(),
      read: false,
    };
    const notifs = [notif, ...this.notificationsSubject.value];
    this.notificationsSubject.next(notifs);
    this.persist(this.NOTIFS_KEY, notifs);
  }

  /** Fires the real, automatic email via EmailJS. See the class-level comment for setup steps. */
  private sendEmailAutomatically(query: ContactQuery): void {
    if (!this.emailjsReady) {
      // eslint-disable-next-line no-console
      console.warn(
        '[EmailJS not configured] Add your Service ID / Template ID / Public Key in NotificationService ' +
          'to make automatic email sending live. The enquiry is still saved and visible to the admin in-app.'
      );
      this.emailStatusSubject.next('not-configured');
      return;
    }

    this.emailStatusSubject.next('sending');

    emailjs
      .send(
        this.EMAILJS_SERVICE_ID,
        this.EMAILJS_TEMPLATE_ID,
        {
          from_name: query.name,
          from_email: query.email,
          phone: query.phone || 'Not provided',
          package: query.relatedPackage || 'General enquiry',
          message: query.message,
        },
        this.EMAILJS_PUBLIC_KEY
      )
      .then(() => this.emailStatusSubject.next('sent'))
      .catch((err: unknown) => {
        // eslint-disable-next-line no-console
        console.error('EmailJS send failed:', err);
        this.emailStatusSubject.next('failed');
      });
  }

  private persist<T>(key: string, value: T): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  private readList<T>(key: string): T[] {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    try {
      return JSON.parse(raw) as T[];
    } catch {
      return [];
    }
  }
}
