import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FeedPost } from '../models/models';

/**
 * Backs the "Updates" feed — a Facebook-style scrollable list of posts.
 * Admin can publish new posts (with an optional image); everyone can scroll
 * through them, newest first, and tap Like. Persisted to localStorage for
 * this static demo; swap `persist()`/`readList()` for real API calls once a
 * backend exists and every component using `posts$` keeps working unchanged.
 */
@Injectable({ providedIn: 'root' })
export class FeedService {
  private readonly POSTS_KEY = 'pledge_feed_posts';

  private postsSubject = new BehaviorSubject<FeedPost[]>(this.readSeeded());
  posts$ = this.postsSubject.asObservable();

  addPost(authorName: string, message: string, image?: string): void {
    const post: FeedPost = {
      id: `post_${Date.now().toString(36)}`,
      authorName,
      message,
      image: image?.trim() || undefined,
      createdAt: new Date().toISOString(),
      likes: 0,
    };
    const posts = [post, ...this.postsSubject.value];
    this.postsSubject.next(posts);
    this.persist(posts);
  }

  deletePost(id: string): void {
    const posts = this.postsSubject.value.filter((p) => p.id !== id);
    this.postsSubject.next(posts);
    this.persist(posts);
  }

  like(id: string): void {
    const posts = this.postsSubject.value.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p));
    this.postsSubject.next(posts);
    this.persist(posts);
  }

  private persist(posts: FeedPost[]): void {
    localStorage.setItem(this.POSTS_KEY, JSON.stringify(posts));
  }

  private readSeeded(): FeedPost[] {
    const raw = localStorage.getItem(this.POSTS_KEY);
    if (raw) {
      try {
        return JSON.parse(raw) as FeedPost[];
      } catch {
        /* fall through to seed */
      }
    }
    const seed: FeedPost[] = [
      {
        id: 'post_seed3',
        authorName: 'Pledge India Tourism',
        message:
          'Zuluk homestays are fully booked for the Nov 10-20 window already — if you are planning the Silk Route for peak season, lock your dates early!',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString(),
        likes: 14,
      },
      {
        id: 'post_seed2',
        authorName: 'Pledge India Tourism',
        message:
          'Fresh batch photos from last week\'s Gangtok group at Tsomgo Lake — clear skies, and the yaks were out in full force. 📸',
        image: 'https://images.unsplash.com/photo-1668350202638-046c51e1d4de?auto=format&fit=crop&w=900&q=80',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 30).toISOString(),
        likes: 22,
      },
      {
        id: 'post_seed1',
        authorName: 'Pledge India Tourism',
        message:
          'New package alert: Darjeeling Hills & Tea Trails is now bookable for the winter season. Toy train joy rides run daily, weather permitting.',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
        likes: 31,
      },
    ];
    this.persist(seed);
    return seed;
  }
}
