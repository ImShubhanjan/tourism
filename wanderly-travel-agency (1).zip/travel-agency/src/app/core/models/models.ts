export type UserRole = 'admin' | 'viewer';

export interface User {
  name: string;
  email: string;
  role: UserRole;
}

export interface Destination {
  id: string;
  name: string;
  country: string;
  image: string;
  packageCount: number;
}

export interface ItineraryDay {
  day: number;
  title: string;
  description: string;
}

export interface TransportOption {
  type: string;
  priceWithMeals: number;
  priceWithoutMeals: number;
  note: string;
}

export interface TourPackage {
  id: string;
  title: string;
  destinationId: string;
  destination: string;
  image: string;
  gallery: string[];
  duration: string;
  price: number;
  rating: number;
  reviewCount: number;
  category: string;
  groupSize: string;
  highlights: string[];
  itinerary: ItineraryDay[];
  inclusions: string[];
  exclusions: string[];
  transportOptions: TransportOption[];
  permitRequired: boolean;
  permitNote: string;
  featured: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  trip: string;
  avatar: string;
  rating: number;
  comment: string;
}

export interface HeroSlide {
  id: number;
  image: string;
  title: string;
  subtitle: string;
}

export interface WhyChooseUsItem {
  icon: string;
  title: string;
  description: string;
}

export interface SiteInfo {
  name: string;
  tagline: string;
  phone: string;
  email: string;
  address: string;
  social: { facebook: string; instagram: string; twitter: string };
}

export interface SiteData {
  siteInfo: SiteInfo;
  heroSlides: HeroSlide[];
  destinations: Destination[];
  packages: TourPackage[];
  testimonials: Testimonial[];
  whyChooseUs: WhyChooseUsItem[];
}

export interface ContactQuery {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  relatedPackage: string;
  message: string;
  createdAt: string;
  status: 'new' | 'read' | 'resolved';
}

export interface FeedPost {
  id: string;
  authorName: string;
  message: string;
  image?: string;
  createdAt: string;
  likes: number;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  createdAt: string;
  read: boolean;
  link?: string;
  meta?: { name: string; email: string; phone: string; relatedPackage: string; message: string };
}
