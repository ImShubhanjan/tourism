import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { NotificationService } from '../../../../core/services/notification.service';
import { Destination, ItineraryDay, TourPackage, TransportOption } from '../../../../core/models/models';

@Component({
  selector: 'app-package-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './package-form.component.html',
  styleUrl: './package-form.component.scss',
})
export class PackageFormComponent implements OnInit {
  isEditMode = false;
  editingId: string | null = null;
  destinations: Destination[] = [];

  model = {
    title: '',
    destinationId: '',
    destination: '',
    image: '',
    galleryText: '',
    duration: '',
    price: 0,
    rating: 4.5,
    reviewCount: 0,
    category: 'Hill Station',
    groupSize: '2-6 people',
    highlightsText: '',
    inclusionsText: '',
    exclusionsText: '',
    featured: false,
    permitRequired: false,
    permitNote: '',
  };

  itinerary: ItineraryDay[] = [{ day: 1, title: '', description: '' }];

  transportOptions: TransportOption[] = [
    { type: 'Shared Vehicle (Sumo / Bolero, pooled with other travellers)', priceWithMeals: 0, priceWithoutMeals: 0, note: '' },
    { type: 'Private Vehicle (exclusive Innova / Xylo for your group)', priceWithMeals: 0, priceWithoutMeals: 0, note: '' },
  ];

  categories = ['Hill Station', 'Adventure', 'Offbeat', 'Group Tour', 'Pilgrimage', 'Family'];
  saved = false;

  constructor(
    private dataService: DataService,
    private notificationService: NotificationService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.dataService.load().subscribe(() => {
      this.destinations = this.dataService.snapshotSiteData?.destinations || [];

      const id = this.route.snapshot.paramMap.get('id');
      if (id) {
        this.isEditMode = true;
        this.editingId = id;
        const existing = this.dataService.getPackageById(id);
        if (existing) this.hydrate(existing);
      }
    });
  }

  hydrate(pkg: TourPackage): void {
    this.model = {
      title: pkg.title,
      destinationId: pkg.destinationId,
      destination: pkg.destination,
      image: pkg.image,
      galleryText: pkg.gallery.join('\n'),
      duration: pkg.duration,
      price: pkg.price,
      rating: pkg.rating,
      reviewCount: pkg.reviewCount,
      category: pkg.category,
      groupSize: pkg.groupSize,
      highlightsText: pkg.highlights.join('\n'),
      inclusionsText: pkg.inclusions.join('\n'),
      exclusionsText: pkg.exclusions.join('\n'),
      featured: pkg.featured,
      permitRequired: pkg.permitRequired,
      permitNote: pkg.permitNote,
    };
    this.itinerary = pkg.itinerary.map((d) => ({ ...d }));
    if (pkg.transportOptions?.length) {
      this.transportOptions = pkg.transportOptions.map((t) => ({ ...t }));
    }
  }

  onDestinationChange(): void {
    const dest = this.destinations.find((d) => d.id === this.model.destinationId);
    if (dest) this.model.destination = `${dest.name}, ${dest.country}`;
  }

  addItineraryDay(): void {
    this.itinerary.push({ day: this.itinerary.length + 1, title: '', description: '' });
  }

  removeItineraryDay(index: number): void {
    this.itinerary.splice(index, 1);
    this.itinerary = this.itinerary.map((d, i) => ({ ...d, day: i + 1 }));
  }

  private linesToArray(text: string): string[] {
    return text
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);
  }

  save(): void {
    const gallery = this.linesToArray(this.model.galleryText);

    const pkg: TourPackage = {
      id: this.editingId || this.dataService.generateId('p'),
      title: this.model.title,
      destinationId: this.model.destinationId,
      destination: this.model.destination,
      image: this.model.image,
      gallery: gallery.length ? gallery : [this.model.image],
      duration: this.model.duration,
      price: Number(this.model.price),
      rating: Number(this.model.rating),
      reviewCount: Number(this.model.reviewCount),
      category: this.model.category,
      groupSize: this.model.groupSize,
      highlights: this.linesToArray(this.model.highlightsText),
      itinerary: this.itinerary.filter((d) => d.title.trim() || d.description.trim()),
      inclusions: this.linesToArray(this.model.inclusionsText),
      exclusions: this.linesToArray(this.model.exclusionsText),
      transportOptions: this.transportOptions.map((t) => ({
        ...t,
        priceWithMeals: Number(t.priceWithMeals),
        priceWithoutMeals: Number(t.priceWithoutMeals),
      })),
      permitRequired: this.model.permitRequired,
      permitNote: this.model.permitRequired ? this.model.permitNote : '',
      featured: this.model.featured,
    };

    if (this.isEditMode) {
      this.dataService.updatePackage(pkg);
      this.notificationService.showToast(`"${pkg.title}" was updated.`);
    } else {
      this.dataService.addPackage(pkg);
      this.notificationService.showToast(`"${pkg.title}" was added.`);
    }

    this.router.navigate(['/admin/packages']);
  }
}
