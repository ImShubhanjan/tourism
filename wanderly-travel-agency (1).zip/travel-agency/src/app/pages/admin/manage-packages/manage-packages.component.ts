import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../../core/services/data.service';
import { NotificationService } from '../../../core/services/notification.service';
import { TourPackage } from '../../../core/models/models';

@Component({
  selector: 'app-manage-packages',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './manage-packages.component.html',
  styleUrl: './manage-packages.component.scss',
})
export class ManagePackagesComponent implements OnInit {
  packages: TourPackage[] = [];
  pendingDeleteId: string | null = null;

  constructor(private dataService: DataService, private notificationService: NotificationService) {}

  ngOnInit(): void {
    this.dataService.load().subscribe();
    this.dataService.packages$.subscribe((p) => (this.packages = p));
  }

  confirmDelete(id: string): void {
    this.pendingDeleteId = id;
  }

  cancelDelete(): void {
    this.pendingDeleteId = null;
  }

  deletePackage(pkg: TourPackage): void {
    this.dataService.deletePackage(pkg.id);
    this.pendingDeleteId = null;
    this.notificationService.showToast(`"${pkg.title}" was removed.`);
  }
}
