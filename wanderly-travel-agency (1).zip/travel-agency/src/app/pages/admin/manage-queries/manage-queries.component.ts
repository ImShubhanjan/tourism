import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../../../core/services/notification.service';
import { ContactQuery } from '../../../core/models/models';

@Component({
  selector: 'app-manage-queries',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-queries.component.html',
  styleUrl: './manage-queries.component.scss',
})
export class ManageQueriesComponent implements OnInit {
  queries: ContactQuery[] = [];
  filter: 'all' | 'new' | 'read' | 'resolved' = 'all';

  constructor(private notificationService: NotificationService) {}

  ngOnInit(): void {
    this.notificationService.queries$.subscribe((q) => (this.queries = q));
  }

  get filtered(): ContactQuery[] {
    if (this.filter === 'all') return this.queries;
    return this.queries.filter((q) => q.status === this.filter);
  }

  markRead(q: ContactQuery): void {
    this.notificationService.markAsRead(q.id);
  }

  markResolved(q: ContactQuery): void {
    this.notificationService.markAsResolved(q.id);
  }
}
