import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { TicketCardComponent } from '../../shared/ticket-card/ticket-card.component';
import { HeroSlide, TourPackage } from '../../core/models/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, TicketCardComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit, OnDestroy {
  siteData$ = this.dataService.siteData$;
  packages$ = this.dataService.packages$;
  destinations$ = this.dataService.destinations$;

  activeSlide = 0;
  private timer?: ReturnType<typeof setInterval>;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    this.dataService.load().subscribe((data) => {
      this.timer = setInterval(() => {
        this.activeSlide = (this.activeSlide + 1) % data.heroSlides.length;
      }, 5500);
    });
  }

  ngOnDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  goToSlide(i: number): void {
    this.activeSlide = i;
  }

  featured(packages: TourPackage[]): TourPackage[] {
    return packages.filter((p) => p.featured).slice(0, 3);
  }

  trackSlide(_i: number, slide: HeroSlide): number {
    return slide.id;
  }
}
