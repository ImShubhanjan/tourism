import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss',
})
export class AboutComponent implements OnInit {
  siteData$ = this.dataService.siteData$;

  stats = [
    { value: '12,000+', label: 'Happy travellers' },
    { value: '15+', label: 'Hill destinations covered' },
    { value: '10', label: 'Years of experience' },
    { value: '4.7/5', label: 'Average rating' },
  ];

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    this.dataService.load().subscribe();
  }
}
