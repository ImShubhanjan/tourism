import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  activeTab: 'password' | 'otp' = 'password';

  username = '';
  password = '';
  errorMessage = '';

  otpPhone = '';
  otpCode = '';
  otpSent = false;
  otpDisplay = '';
  otpError = '';

  constructor(private auth: AuthService, private router: Router) {}

  switchTab(tab: 'password' | 'otp'): void {
    this.activeTab = tab;
  }

  submit(): void {
    const result = this.auth.login(this.username, this.password);
    if (!result.ok) {
      this.errorMessage = result.error || 'Login failed.';
      return;
    }
    this.errorMessage = '';
    this.router.navigate(['/admin']);
  }

  fillDemo(): void {
    this.username = 'admin';
    this.password = 'pledge123';
  }

  sendOtp(): void {
    if (!this.otpPhone.trim()) return;
    this.otpDisplay = this.auth.requestOtp(this.otpPhone.trim());
    this.otpSent = true;
    this.otpCode = '';
    this.otpError = '';
  }

  changeNumber(): void {
    this.otpSent = false;
  }

  verifyOtp(): void {
    const result = this.auth.verifyOtp(this.otpCode);
    if (!result.ok) {
      this.otpError = result.error || 'Verification failed.';
      return;
    }
    this.otpError = '';
    this.router.navigate(['/admin']);
  }
}
