import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { TicketCardComponent } from '../../shared/ticket-card/ticket-card.component';
import { Destination, TourPackage } from '../../core/models/models';

@Component({
  selector: 'app-packages',
  standalone: true,
  imports: [CommonModule, FormsModule, TicketCardComponent],
  templateUrl: './packages.component.html',
  styleUrl: './packages.component.scss',
})
export class PackagesComponent implements OnInit {
  allPackages: TourPackage[] = [];
  destinations: Destination[] = [];
  filtered: TourPackage[] = [];

  searchTerm = '';
  selectedDestination = 'all';
  selectedCategory = 'all';
  sortBy: 'popular' | 'price-low' | 'price-high' = 'popular';

  categories = ['Hill Station', 'Adventure', 'Offbeat', 'Group Tour'];

  constructor(private dataService: DataService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.dataService.load().subscribe();

    this.route.queryParams.subscribe((params) => {
      if (params['destination']) this.selectedDestination = params['destination'];
    });

    this.dataService.destinations$.subscribe((dest) => (this.destinations = dest));
    this.dataService.packages$.subscribe((pkgs) => {
      this.allPackages = pkgs;
      this.applyFilters();
    });
  }

  applyFilters(): void {
    let list = [...this.allPackages];

    if (this.searchTerm.trim()) {
      const term = this.searchTerm.trim().toLowerCase();
      list = list.filter(
        (p) => p.title.toLowerCase().includes(term) || p.destination.toLowerCase().includes(term)
      );
    }

    if (this.selectedDestination !== 'all') {
      list = list.filter((p) => p.destinationId === this.selectedDestination);
    }

    if (this.selectedCategory !== 'all') {
      list = list.filter((p) => p.category === this.selectedCategory);
    }

    if (this.sortBy === 'price-low') list.sort((a, b) => a.price - b.price);
    if (this.sortBy === 'price-high') list.sort((a, b) => b.price - a.price);
    if (this.sortBy === 'popular') list.sort((a, b) => b.rating - a.rating);

    this.filtered = list;
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.selectedDestination = 'all';
    this.selectedCategory = 'all';
    this.sortBy = 'popular';
    this.applyFilters();
  }
}
