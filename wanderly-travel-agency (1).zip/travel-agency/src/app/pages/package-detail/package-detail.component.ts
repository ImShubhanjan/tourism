import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { NotificationService } from '../../core/services/notification.service';
import { AuthService } from '../../core/services/auth.service';
import { TourPackage } from '../../core/models/models';

@Component({
  selector: 'app-package-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './package-detail.component.html',
  styleUrl: './package-detail.component.scss',
})
export class PackageDetailComponent implements OnInit {
  pkg?: TourPackage;
  activeImage = '';
  notFound = false;

  constructor(
    private route: ActivatedRoute,
    private dataService: DataService,
    private notificationService: NotificationService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.dataService.load().subscribe(() => {
      this.pkg = this.dataService.getPackageById(id);
      if (!this.pkg) {
        this.notFound = true;
      } else {
        this.activeImage = this.pkg.image;
      }
    });
  }

  setActiveImage(img: string): void {
    this.activeImage = img;
  }

  quickEnquire(): void {
    if (!this.pkg) return;
    this.notificationService.submitQuery({
      name: this.auth.currentUser?.name || 'Website visitor',
      email: this.auth.currentUser?.email || 'not-provided@example.com',
      phone: '',
      subject: `Enquiry: ${this.pkg.title}`,
      relatedPackage: this.pkg.title,
      message: `I'm interested in the "${this.pkg.title}" package. Please share more details / availability.`,
    });
  }
}
