import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { FeedService } from '../../core/services/feed.service';

@Component({
  selector: 'app-feed',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feed.component.html',
  styleUrl: './feed.component.scss',
})
export class FeedComponent {
  posts$ = this.feedService.posts$;
  currentUser$ = this.authService.currentUser$;

  newMessage = '';
  newImage = '';

  constructor(private feedService: FeedService, private authService: AuthService) {}

  post(): void {
    if (!this.newMessage.trim()) return;
    this.feedService.addPost('Pledge India Tourism', this.newMessage.trim(), this.newImage.trim());
    this.newMessage = '';
    this.newImage = '';
  }

  like(id: string): void {
    this.feedService.like(id);
  }

  deletePost(id: string): void {
    if (confirm('Remove this update?')) this.feedService.deletePost(id);
  }

  timeAgo(iso: string): string {
    const diffMs = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }
}
