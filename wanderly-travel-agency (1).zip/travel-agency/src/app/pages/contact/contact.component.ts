import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../core/services/data.service';
import { NotificationService } from '../../core/services/notification.service';
import { TourPackage } from '../../core/models/models';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss',
})
export class ContactComponent implements OnInit {
  siteData$ = this.dataService.siteData$;
  packages: TourPackage[] = [];
  emailStatus$ = this.notificationService.emailStatus$;

  form = {
    name: '',
    email: '',
    phone: '',
    subject: '',
    relatedPackage: '',
    message: '',
  };

  submitted = false;
  errors: Partial<Record<keyof typeof this.form, string>> = {};

  constructor(
    private dataService: DataService,
    private notificationService: NotificationService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.dataService.load().subscribe();
    this.dataService.packages$.subscribe((p) => (this.packages = p));

    this.route.queryParams.subscribe((params) => {
      if (params['package']) {
        this.form.relatedPackage = params['package'];
        this.form.subject = `Booking enquiry: ${params['package']}`;
      }
    });
  }

  validate(): boolean {
    this.errors = {};
    if (!this.form.name.trim()) this.errors.name = 'Please enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.form.email)) this.errors.email = 'Enter a valid email address.';
    if (!this.form.message.trim()) this.errors.message = 'Tell us a little about your query.';
    return Object.keys(this.errors).length === 0;
  }

  submit(): void {
    if (!this.validate()) return;

    this.notificationService.submitQuery({ ...this.form });

    this.submitted = true;
    this.form = { name: '', email: '', phone: '', subject: '', relatedPackage: '', message: '' };
  }

  sendAnother(): void {
    this.submitted = false;
  }
}
